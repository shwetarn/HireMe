/**
 * 
 */
/**
 * 
 */
module HireME {
	requires java.desktop;
	requires java.sql;
}