package HireMe;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class viewApplicationDetails extends JFrame {

	private JPanel contentPane;
	private JTextField userIDValue;
	private JTextField passwordValue;
	public static String userID;
	public static String userPassword;

	/**
	 * Launch the application.
	 */
	public static void loginUser(String clickerUserLabel) {
		System.out.println(clickerUserLabel);
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewApplicationDetails frame = new viewApplicationDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public viewApplicationDetails() {
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 680, 525);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		JLabel errorMessage = new JLabel("ID or PASSWORD do not match! Please retry!");
		errorMessage.setForeground(Color.red);
		errorMessage.setBounds(50, 210, 800, 100);
		
		JLabel registerNow = new JLabel("New to HIRE!ME ? Register as an applicant here!");
		registerNow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println(registerNow.getText());
			}
			public void mouseEntered(MouseEvent e) {
				registerNow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	registerNow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
		});
		registerNow.setBounds(0, 350, 350, 100);
		registerNow.setHorizontalAlignment(SwingConstants.CENTER);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("HIRE!");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblNewLabel_1.setBounds(0, 50, 1280, 50);
		lblNewLabel_1.setForeground(Color.blue);
		contentPane.add(lblNewLabel_1);
		JLabel lblNewLabel_2 = new JLabel("ME");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblNewLabel_2.setBounds(100, 50, 1280, 50);
		lblNewLabel_2.setForeground(Color.black);
		contentPane.add(lblNewLabel_2);
		JLabel lblNewLabel_21 = new JLabel("Make your strike count!");
		lblNewLabel_21.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_21.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_21.setBounds(38, 100, 1280, 50);
		lblNewLabel_21.setForeground(Color.black);
		contentPane.add(lblNewLabel_21);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		panel.setBounds(482, 201, 350, 415);
		contentPane.add(panel);
		panel.setLayout(null);
//		panel.setLayout(new FlowLayout());
//		JScrollPane jp=new JScrollPane(panel,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//		jp.setSize(100, 100);
//		jp.setViewportView(panel);
//		jp.setBounds(482, 201, 350, 415);
//		jp.setLayout(new FlowLayout());
//		contentPane.add(jp);
		
		JLabel panelLabel = new JLabel("");
		panelLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panelLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panelLabel.setBounds(0, 14, 350, 19);
		panel.add(panelLabel);
		panel.setOpaque(false);
		passwordValue = new JTextField();
		passwordValue.setColumns(20);
		passwordValue.setBounds(25, 216, 300, 30);
		passwordValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		passwordValue.setOpaque(false);
		JLabel passwordLabel = new JLabel("PASSWORD");
		passwordLabel.setBounds(25, 185, 100, 14);
		JLabel lblNewLabel_3 = new JLabel("APPLICANT ID");
		lblNewLabel_3.setBounds(25, 85, 149, 14);
		userIDValue = new JTextField();
		userIDValue.setBounds(25, 116, 300, 30);
		userIDValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		userIDValue.setOpaque(false);
		userIDValue.setColumns(20);
		
		//Login as applicant
		
		JButton loginButton = new JButton("Login as Applicant");
		loginButton.setBounds(102, 300, 146, 23);
		loginButton.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.BLACK));
		loginButton.setBackground(new Color(0,0,0,0));
		
		JButton loginApplicant = new JButton("LOGIN AS APPLICANT");
		loginApplicant.setBackground(new Color(0, 0, 0, 80));
		loginApplicant.setForeground(Color.white);
		loginApplicant.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int userType=-1;
				loginUser(loginButton.getLabel());
				System.out.println("userIDValue"+userIDValue.getText());
				System.out.println("password"+passwordValue.getText());
				
				String DB_URL = "jdbc:mysql://localhost/firstTry";
				String USER = "root";
				String PASS = "root";
				
				String sqlLogin ="";
				if(loginButton.getLabel().equals("Login as Applicant")){
					sqlLogin = "SELECT * FROM applicantInfo" +" WHERE (applicantID = "+userIDValue.getText()+" and applicantPassword = '"+passwordValue.getText()+"');";
					userType=1;
					}
				
				else if(loginButton.getLabel().equals("Login as Employer")) {
					sqlLogin = "SELECT * FROM companyInfo" +" WHERE (companyID = "+userIDValue.getText()+" and companyPassword = '"+passwordValue.getText()+"');";
					userType=2;
				}
				
				else if(loginButton.getLabel().equals("Login as Admin")) {
					sqlLogin = "SELECT * FROM adminInfo" +" WHERE (adminID = "+userIDValue.getText()+" and adminPassword = '"+passwordValue.getText()+"');";
					userType=3;
				}
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					
					ResultSet rs = stmt.executeQuery(sqlLogin);
					rs = stmt.executeQuery(sqlLogin);
					if(rs.next())
					{
						panel.remove(errorMessage);
						rs = stmt.executeQuery(sqlLogin);
						while(rs.next()){
							if(userType==1) {
								homeApplicant homeApp = new homeApplicant();
								homeApp.userID=rs.getString("applicantID");
								homeApp.userName=rs.getString("applicantName");
								homeApp.userEMail=rs.getString("applicantEMail");
								homeApp.phoneNumber=rs.getString("applicantMobile");
								homeApp.main(null);
							}
							dispose();
							}
						}
					else {
						System.out.println(errorMessage.getText());
						panel.add(errorMessage);
					}
					conn.close();
				} catch (SQLException errorSQL) {
				}
			}
		});
		
		loginApplicant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(errorMessage);
				
				panel.setOpaque(true);
				panelLabel.setText("LOGIN AS APPLICANT");
				panel.remove(userIDValue);
				panel.remove(lblNewLabel_3);
				panel.remove(passwordLabel);
				panel.remove(passwordValue);
				panel.remove(loginButton);
				userIDValue.setText(null);
				passwordValue.setText(null);
				panel.remove(registerNow);
				
				lblNewLabel_3.setText("APPLICANT ID");
				panel.add(userIDValue);
				panel.add(lblNewLabel_3);
				panel.add(passwordLabel);
				panel.add(passwordValue);
				panel.add(loginButton);
				loginButton.setLabel("Login as Applicant");
				registerNow.setText("New to HIRE!ME ? Register as an applicant here!");
				panel.add(registerNow);
				
			}
		});
		loginApplicant.setBounds(100, 150, 193, 25);
		contentPane.add(loginApplicant);
		
		JButton loginEmployer = new JButton("LOGIN AS EMPLOYER");
		loginEmployer.setBackground(new Color(0, 0, 0, 80));
		loginEmployer.setForeground(Color.white);
		loginEmployer.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		loginEmployer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(errorMessage);
				
				panel.setOpaque(true);
				panelLabel.setText("LOGIN AS EMPLOYER");
				panel.remove(userIDValue);
				panel.remove(lblNewLabel_3);
				panel.remove(passwordLabel);
				panel.remove(passwordValue);
				panel.add(loginButton);
				loginButton.setLabel("Login as Employer");
				userIDValue.setText(null);
				passwordValue.setText(null);
				panel.remove(registerNow);
				
				lblNewLabel_3.setText("EMPLOYER ID");
				panel.add(userIDValue);
				panel.add(lblNewLabel_3);
				panel.add(passwordLabel);
				panel.add(passwordValue);
				registerNow.setText("New to HIRE!ME ? Register as an employer here!");
				panel.add(registerNow);
			}
		});
		loginEmployer.setBounds(315, 150, 193, 25);
		contentPane.add(loginEmployer);
		
		JButton registerApplicant = new JButton("REGISTER AS APPLICANT");
		registerApplicant.setBounds(530, 150, 193, 25);
		registerApplicant.setBackground(new Color(0, 0, 0, 80));
		registerApplicant.setForeground(Color.white);
		registerApplicant.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		contentPane.add(registerApplicant);
		registerApplicant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(errorMessage);
				
				panel.setOpaque(true);
				panelLabel.setText("REGISTER AS APPLICANT");
				panel.remove(userIDValue);
				panel.remove(lblNewLabel_3);
				panel.remove(passwordLabel);
				panel.remove(passwordValue);
				panel.remove(loginButton);
				userIDValue.setText(null);
				passwordValue.setText(null);
				panel.remove(registerNow);
				registerApplicant registerAsApplicant = new registerApplicant();
				registerAsApplicant.main(null);
				dispose();
				
			}
		});
		
		JButton registerCompany = new JButton("REGISTER AS COMPANY");
		registerCompany.setBounds(745, 150, 193, 25);
		registerCompany.setBackground(new Color(0, 0, 0, 80));
		registerCompany.setForeground(Color.white);
		registerCompany.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		contentPane.add(registerCompany);
		registerCompany.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(errorMessage);
				
				panel.setOpaque(true);
				panelLabel.setText("REGISTER AS COMPANY");
				panel.remove(userIDValue);
				panel.remove(lblNewLabel_3);
				panel.remove(passwordLabel);
				panel.remove(passwordValue);
				panel.remove(loginButton);
				userIDValue.setText(null);
				passwordValue.setText(null);
				panel.remove(registerNow);
				registerCompany registerAsCompany = new registerCompany();
				registerAsCompany.main(null);
				dispose();
				
			}
		});
		
		JButton loginAdmin = new JButton("LOGIN AS ADMIN");
		loginAdmin.setBounds(960, 150, 193, 25);
		loginAdmin.setBackground(new Color(0, 0, 0, 80));
		loginAdmin.setForeground(Color.white);
		loginAdmin.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		loginAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.remove(errorMessage);
				
				panel.setOpaque(true);
				panelLabel.setText("LOGIN AS ADMIN");
				panel.remove(userIDValue);
				panel.remove(lblNewLabel_3);
				panel.remove(passwordLabel);
				panel.remove(passwordValue);
				panel.add(loginButton);
				loginButton.setLabel("Login as Admin");
				userIDValue.setText(null);
				passwordValue.setText(null);
				panel.remove(registerNow);
				
				lblNewLabel_3.setText("ADMIN ID");
				panel.add(userIDValue);
				panel.add(lblNewLabel_3);
				panel.add(passwordLabel);
				panel.add(passwordValue);
				
			}
		});
		contentPane.add(loginAdmin);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shweta.rn\\Downloads\\Untitled design (17).gif"));
		lblNewLabel.setBounds(0, 0, 1280, 720);
		contentPane.add(lblNewLabel);
	}
}
