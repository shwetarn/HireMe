package HireMe;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class vacancyTableApplied extends JFrame {

	private static JPanel contentPane;
	private static JLabel questionOne,questionFive,questionFour,questionThree,questionTwo;

	/**
	 * Launch the application.
	 */
	public static String userID=-1+"";
	public static String userEMail="";
	public static String userName="";
	public static String phoneNumber="";
	public static ArrayList<Object> assessmentInfo=new ArrayList<Object>();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vacancyTableApplied frame = new vacancyTableApplied();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public static String DB_URL = "jdbc:mysql://localhost/firstTry";
	public static String USER = "root";
	public static String PASS = "root";
	
	public static ArrayList abc(String indexJob) {
		ArrayList<Object> temp=new ArrayList<Object>();
		try(Connection connect = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmtect = connect.createStatement();
			String companyName="select * from availableVacancy where ID="+indexJob+";";
			ResultSet rsect = stmtect.executeQuery(companyName);
			while(rsect.next()) {
				temp.add(rsect.getString("questionOne"));
				temp.add(rsect.getString("questionTwo"));
				temp.add(rsect.getString("questionThree"));
				temp.add(rsect.getString("questionFour"));
				temp.add(rsect.getString("questionFive"));
				temp.add(rsect.getString("answerOne"));
				temp.add(rsect.getString("answerTwo"));
				temp.add(rsect.getString("answerThree"));
				temp.add(rsect.getString("answerFour"));
				temp.add(rsect.getString("answerFive"));
				temp.add(rsect.getString("optionsOne"));
				temp.add(rsect.getString("optionsTwo"));
				temp.add(rsect.getString("optionsThree"));
				temp.add(rsect.getString("optionsFour"));
				temp.add(rsect.getString("optionsFive"));
				assessmentInfo=temp;
//				displayInfo(indexJob);
				}
			
			connect.close();
			return assessmentInfo;
		} catch (SQLException errorSQL) {
		}
		return assessmentInfo;
	}
	public static void displayInfo(String indexJob) {
		ArrayList<Object> neww=new ArrayList<Object>();
		neww=abc(indexJob);
		System.out.println("neww"+neww);
		if(neww.size()>15) {
			for(int i=0;i<neww.size();i++) {
				if(i==0) {
					questionOne.setText("");
					contentPane.add(questionOne);
					}
				else if(i==4) {
					questionFive.setText("");
					contentPane.add(questionFive);
				}
				else if(i==3) {
					questionFour.setText("");
					contentPane.add(questionFour);
				}
				else if(i==2) {
					questionThree.setText("");
					contentPane.add(questionThree);
				}
				else if(i==1) {
					questionTwo.setText("");
					contentPane.add(questionTwo);
				}
				}
			}
	}
	public vacancyTableApplied() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Assessment");
		lblNewLabel_1.setBounds(25, 21, 49, 14);
		contentPane.add(lblNewLabel_1);
		
//		JLabel questionOne = new JLabel("");
		questionOne.setText(" ");
		questionOne.setBounds(20, 70, 1024, 20);
		
//		JLabel questionFive = new JLabel("");
		questionFive.setText(" ");
		questionFive.setBounds(20, 190, 1024, 20);
		
//		JLabel questionFour = new JLabel("");
		questionFour.setText(" ");
		questionFour.setBounds(20, 160, 1024, 20);
		
//		JLabel questionFour,questionThree = new JLabel("");
		questionThree.setText(" ");
		questionThree.setBounds(20, 130, 1024, 20);
		
//		JLabel questionFour,questionThree,questionTwo = new JLabel("");
		questionTwo.setText(" ");
		questionTwo.setBounds(20, 100, 1024, 20);
	
	
		
        String DB_URL = "jdbc:mysql://localhost/firstTry";
		String USER = "root";
		String PASS = "root";
        
        	try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
    			Statement stmt = conn.createStatement();
    			
    			String applicantAppliedDetails ="Select * from applications where applicantID="+userID+";";
    			ResultSet rs = stmt.executeQuery(applicantAppliedDetails);
    			rs = stmt.executeQuery(applicantAppliedDetails);
    			if(rs.next())
    			{
    				rs = stmt.executeQuery(applicantAppliedDetails);
    				String companyName="select * from companyInfo where companyID="+rs.getString("companyID")+";";
    				ResultSet companyInfo = stmt.executeQuery(companyName);
    				while(companyInfo.next()) {
    					
    				}
    				while(rs.next()){
    					
    					}
    				}
    			conn.close();
    		} catch (SQLException errorSQL) {
    		}

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shweta.rn\\Downloads\\Untitled design (18).gif"));
		lblNewLabel.setBounds(0, 0, 1280, 720);
		contentPane.add(lblNewLabel);

	}
}
