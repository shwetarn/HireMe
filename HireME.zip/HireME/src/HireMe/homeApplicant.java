package HireMe;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;

public class homeApplicant extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
	public static String DB_URL = "jdbc:mysql://localhost/firstTry";
	public static String USER = "root";
	public static String PASS = "root";
	
	
	public static String userID=-1+"";
	public static String userEMail="";
	public static String userName="";
	public static String phoneNumber="";
	
	int totalApplications=0;
	int totalSelected=0;
	int totalNotSelected=0;
	int totalInProgress=0;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					homeApplicant frame = new homeApplicant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public homeApplicant() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 694, 612);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel Fullpanel = new JPanel();
		Fullpanel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		Fullpanel.setBounds(350, 0, 1400, 720);
		contentPane.add(Fullpanel);
		Fullpanel.setLayout(null);
		Fullpanel.setOpaque(false);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		panel.setBounds(0, 0, 350, 720);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel hireMeLogo = new JLabel("HIRE!ME");
		hireMeLogo.setBounds(1155, 10, 1280, 30);
		hireMeLogo.setForeground(Color.WHITE);
		hireMeLogo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(hireMeLogo);
		
		JLabel pageTitle = new JLabel("Applicant Dashboard");
		pageTitle.setBounds(365, 20, 800, 40);
		pageTitle.setFont(new Font("Tahoma", Font.PLAIN, 34));
		contentPane.add(pageTitle);
		
		JLabel userNameTitle = new JLabel("Hello " + userName);
		userNameTitle.setBounds(365, 70, 400, 40);
		userNameTitle.setFont(new Font("Tahoma", Font.PLAIN, 24));
		contentPane.add(userNameTitle);
		
		try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmt = conn.createStatement();
			String sqlLogin = "SELECT * FROM applications" +" WHERE applicantID="+userID+";";
			ResultSet rs = stmt.executeQuery(sqlLogin);
			rs = stmt.executeQuery(sqlLogin);
			if(rs.next())
			{
				rs = stmt.executeQuery(sqlLogin);
				while(rs.next()){
					if(rs.getInt("applicantSelected")==0)
						totalInProgress=totalInProgress+1;
					else if(rs.getInt("applicantSelected")==1)
						totalSelected=totalSelected+1;
					else if(rs.getInt("applicantSelected")==2)
						totalNotSelected=totalNotSelected+1;
					totalApplications=totalInProgress+totalSelected+totalNotSelected;
					}
				}
			conn.close();
		} catch (SQLException errorSQL) {
		}
		
		JPanel totalAppliedBoxDashboard = new JPanel();
		totalAppliedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		totalAppliedBoxDashboard.setBounds(20, 201, 255, 155);
		Fullpanel.add(totalAppliedBoxDashboard);
		totalAppliedBoxDashboard.setLayout(null);
		
		JLabel totalAppliedLabel1 = new JLabel("Total");
		JLabel totalAppliedLabel2 = new JLabel("Applied");
		totalAppliedLabel1.setBounds(15, 5, 400, 35);
		totalAppliedLabel2.setBounds(15, 30, 400, 35);
		totalAppliedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		totalAppliedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		totalAppliedLabel1.setForeground(Color.WHITE);
		totalAppliedLabel2.setForeground(Color.WHITE);
		totalAppliedBoxDashboard.add(totalAppliedLabel2);
		totalAppliedBoxDashboard.add(totalAppliedLabel1);
		
		JLabel totalAppliedCountDashboard = new JLabel(totalApplications+"");
		totalAppliedCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		totalAppliedCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		totalAppliedCountDashboard.setForeground(new Color(255, 255, 255));
		totalAppliedCountDashboard.setBounds(152, 62, 133, 103);
		totalAppliedBoxDashboard.add(totalAppliedCountDashboard);
		
		JPanel inProgressBoxDashboard = new JPanel();
		inProgressBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		inProgressBoxDashboard.setBounds(20, 401, 255, 155);
		Fullpanel.add(inProgressBoxDashboard);
		inProgressBoxDashboard.setLayout(null);
		
		JLabel inProgressLabel1 = new JLabel("In");
		JLabel inProgressLabel2 = new JLabel("Progress");
		inProgressLabel1.setBounds(15, 5, 400, 35);
		inProgressLabel2.setBounds(15, 30, 400, 35);
		inProgressLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		inProgressLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		inProgressLabel1.setForeground(Color.WHITE);
		inProgressLabel2.setForeground(Color.WHITE);
		inProgressBoxDashboard.add(inProgressLabel1);
		inProgressBoxDashboard.add(inProgressLabel2);
		
		JLabel inProgressBoxCountDashboard = new JLabel(totalInProgress+"");
		inProgressBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		inProgressBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		inProgressBoxCountDashboard.setForeground(new Color(255, 255, 255));
		inProgressBoxCountDashboard.setBounds(152, 62, 133, 103);
		inProgressBoxDashboard.add(inProgressBoxCountDashboard);
		
		JPanel notSelectedBoxDashboard = new JPanel();
		notSelectedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		notSelectedBoxDashboard.setBounds(580, 201, 255, 155);
		Fullpanel.add(notSelectedBoxDashboard);
		notSelectedBoxDashboard.setLayout(null);
		
		JLabel notSelectedLabel1 = new JLabel("Not");
		JLabel notSelectedLabel2 = new JLabel("Selected");
		notSelectedLabel1.setBounds(15, 5, 400, 35);
		notSelectedLabel2.setBounds(15, 30, 400, 35);
		notSelectedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		notSelectedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		notSelectedLabel1.setForeground(Color.WHITE);
		notSelectedLabel2.setForeground(Color.WHITE);
		notSelectedBoxDashboard.add(notSelectedLabel1);
		notSelectedBoxDashboard.add(notSelectedLabel2);
		
		JLabel notSelectedBoxCountDashboard = new JLabel(totalNotSelected+"");
		notSelectedBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		notSelectedBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		notSelectedBoxCountDashboard.setForeground(new Color(255, 255, 255));
		notSelectedBoxCountDashboard.setBounds(152, 62, 133, 103);
		notSelectedBoxDashboard.add(notSelectedBoxCountDashboard);
		notSelectedBoxDashboard.setLayout(null);
		
		JPanel selectedBoxDashboard = new JPanel();
		selectedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		selectedBoxDashboard.setBounds(300, 201, 255, 155);
		Fullpanel.add(selectedBoxDashboard);
		
		JLabel selectedLabel1 = new JLabel("Total");
		JLabel selectedLabel2 = new JLabel("Selected");
		selectedLabel1.setBounds(15, 5, 400, 35);
		selectedLabel2.setBounds(15, 30, 400, 35);
		selectedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		selectedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		selectedLabel1.setForeground(Color.WHITE);
		selectedLabel2.setForeground(Color.WHITE);
		selectedBoxDashboard.add(selectedLabel1);
		selectedBoxDashboard.add(selectedLabel2);
		
		JLabel selectedBoxCountDashboard = new JLabel(totalSelected+"");
		selectedBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		selectedBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		selectedBoxCountDashboard.setForeground(new Color(255, 255, 255));
		selectedBoxCountDashboard.setBounds(152, 62, 133, 103);
		selectedBoxDashboard.add(selectedBoxCountDashboard);
		selectedBoxDashboard.setLayout(null);
		
		JButton dashboardBtn = new JButton("DASHBOARD");
		JButton communityWallBtn = new JButton("COMMUNITY WALL");
		JButton totalAppliedBtn = new JButton("APPLIED VACANCIES");
		JButton inProgressBtn = new JButton("IN PROGRESS VACANCIES");
		JButton selectedBtn = new JButton("SELECTED VACANCIES");
		JButton userProfileBtn = new JButton("PROFILE");
		
		
		JButton applyBtn = new JButton("APPLY");
		applyBtn.setBackground(new Color(0, 0, 0, 80));
		applyBtn.setForeground(Color.white);
		applyBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		applyBtn.setBounds(0,240,350,40);
		panel.add(applyBtn);
		
		JPanel textgrid = new JPanel();
		GridLayout gl=new GridLayout(100,100);
		textgrid.setLayout(gl);
		
		JScrollPane jp=new JScrollPane(textgrid,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp.setBounds(20, 201,900,419);
		
		
		applyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textgrid.removeAll();
				Fullpanel.remove(totalAppliedBoxDashboard);
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				textgrid.setOpaque(true);
				textgrid.setBackground(new Color(100,100,100,80));
				textgrid.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
				jp.setOpaque(true);
				jp.setBackground(new Color(100,100,100,0));
				jp.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
				textgrid.removeAll();
				Fullpanel.add(jp);
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String QUERY = "SELECT * FROM availableVacancy;";
					ResultSet rs = stmt.executeQuery(QUERY);
					String sqlaa = "SELECT * FROM availableVacancy;";
					System.out.println("sqlaa"+sqlaa);
					rs = stmt.executeQuery(sqlaa);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlaa);
						while(rs.next()){
							JLabel jobTitle = new JLabel("     "+rs.getString("jobTitle"));
//							jobTitle.setHorizontalAlignment(SwingConstants.CENTER);
							jobTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
							jobTitle.setForeground(Color.white);
							
							JLabel vacancyType = new JLabel("     Vacancy Type: "+rs.getString("vacancyType"));
							vacancyType.setFont(new Font("Tahoma", Font.PLAIN, 15));
							vacancyType.setForeground(Color.white);
							
							JLabel dateOfJoining = new JLabel("     Date of Joining: "+rs.getString("dateOfJoining"));
							dateOfJoining.setFont(new Font("Tahoma", Font.PLAIN, 15));
							dateOfJoining.setForeground(Color.white);
							
//							JLabel applyBtnJob = new JLabel("     Apply Job ID "+rs.getString("ID"));
//							applyBtnJob.setFont(new Font("Tahoma", Font.PLAIN, 17));
							JButton applyBtnJob = new JButton("APPLY Job ID "+ rs.getString("ID"));
							applyBtnJob.setOpaque(false);applyBtnJob.setBackground(new Color(0,0,0,0));
							applyBtnJob.setForeground(Color.white);
							applyBtnJob.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									String indexTemp=applyBtnJob.getLabel();
									indexTemp=indexTemp.substring(13);
									System.out.println("indexTemp"+indexTemp);
								}
							});
							
							JLabel spaceLine = new JLabel("     ");
							spaceLine.setFont(new Font("Tahoma", Font.PLAIN, 18));
							textgrid.add(jobTitle);
							textgrid.add(vacancyType);
							textgrid.add(dateOfJoining);
							textgrid.add(applyBtnJob);
							textgrid.add(spaceLine);
		                }
		           }
		           conn.close();
				} catch (SQLException errorSQL) {
		       	errorSQL.printStackTrace();
		       	}
				
				pageTitle.setText("JOB VACANCIES AVAILABLE");
				applyBtn.setOpaque(false);
				dashboardBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				applyBtn.setForeground(Color.black);
			}
		});
		
		inProgressBtn.setBackground(new Color(0, 0, 0, 80));
		inProgressBtn.setForeground(Color.white);
		inProgressBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		inProgressBtn.setBounds(0,360,350,40);
		panel.add(inProgressBtn);
		
		selectedBtn.setBackground(new Color(0, 0, 0, 80));
		selectedBtn.setForeground(Color.white);
		selectedBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		selectedBtn.setBounds(0,400,350,40);
		panel.add(selectedBtn);
		
		userProfileBtn.setBackground(new Color(0, 0, 0, 80));
		userProfileBtn.setForeground(Color.white);
		userProfileBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		userProfileBtn.setBounds(0,440,350,40);
		panel.add(userProfileBtn);
		
		totalAppliedBtn.setBackground(new Color(0, 0, 0, 80));
		totalAppliedBtn.setForeground(Color.white);
		totalAppliedBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		totalAppliedBtn.setBounds(0,320,350,40);
		panel.add(totalAppliedBtn);
		totalAppliedBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("APPLIED VACANCIES");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(false);
				totalAppliedBtn.setForeground(Color.black);
				textgrid.removeAll();
				
			}
		});
		
		communityWallBtn.setBackground(new Color(0, 0, 0, 80));
		communityWallBtn.setForeground(Color.white);
		communityWallBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		communityWallBtn.setBounds(0,280,350,40);
		panel.add(communityWallBtn);
		communityWallBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textgrid.removeAll();
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("COMMUNITY WALL");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(false);
				totalAppliedBtn.setOpaque(true);
				communityWallBtn.setForeground(Color.black);
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String QUERY = "SELECT * FROM communityWall;";
					ResultSet rs = stmt.executeQuery(QUERY);
					String sqlaa = "SELECT * FROM communityWall;";
					System.out.println("sqlaa"+sqlaa);
					rs = stmt.executeQuery(sqlaa);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlaa);
						while(rs.next()){
							JLabel userName = new JLabel("     Posted by: "+rs.getString("userName"));
							userName.setFont(new Font("Tahoma", Font.PLAIN, 18));
							userName.setForeground(Color.white);
							
							JLabel UserType = new JLabel("     User Type: "+rs.getString("UserType"));
							UserType.setFont(new Font("Tahoma", Font.PLAIN, 15));
							UserType.setForeground(Color.white);
							
							JLabel dateOfJoining = new JLabel("     "+rs.getString("Content"));
							dateOfJoining.setFont(new Font("Tahoma", Font.PLAIN, 15));
							dateOfJoining.setForeground(Color.white);
							
							JLabel spaceLine = new JLabel("     ");
							spaceLine.setFont(new Font("Tahoma", Font.PLAIN, 18));
							
							textgrid.add(userName);
							textgrid.add(UserType);
							textgrid.add(dateOfJoining);
							
							textgrid.setOpaque(true);
							textgrid.setBackground(new Color(100,100,100,80));
							textgrid.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
							jp.setOpaque(true);
							jp.setBackground(new Color(100,100,100,0));
							jp.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
							
							if(userID.equals(rs.getString("UserID")))
							{
								JButton deletePost = new JButton("Delete Post ID "+ rs.getString("PostID"));
								deletePost.setOpaque(false);deletePost.setBackground(new Color(0,0,0,0));
								deletePost.setForeground(Color.white);
								deletePost.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										String indexTemp=deletePost.getLabel();
										indexTemp=indexTemp.substring(15);
										System.out.println("indexTemp"+indexTemp);
										try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		            					         ) {
		            			            String sql= "delete from communityWall where PostID = ?;";
		            			    		PreparedStatement st= conn.prepareStatement(sql);
		            			            st.setString(1, indexTemp);
		            			            st.executeUpdate();
		            			            conn.close();
		            			            dispose();
		            					} catch (SQLException errorSQL) {
		            		            	errorSQL.printStackTrace();
		            		            	}
									}
								});
								deletePost.setForeground(Color.RED);
								textgrid.add(deletePost);
							}
							textgrid.add(spaceLine);
							Fullpanel.add(jp);
		                }
		           }
		           conn.close();
				} catch (SQLException errorSQL) {
		       	errorSQL.printStackTrace();
		       	}
				
				
			}
		});
		
		dashboardBtn.setBackground(new Color(0, 0, 0, 80));
		dashboardBtn.setForeground(Color.white);
		dashboardBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		dashboardBtn.setBounds(0,200,350,40);
		panel.add(dashboardBtn);
		dashboardBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textgrid.removeAll();
				applyBtn.setOpaque(true);
				Fullpanel.remove(jp);
				dashboardBtn.setOpaque(false);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				dashboardBtn.setForeground(Color.black);
				
				pageTitle.setText("Applicant Dashboard");
				userNameTitle.setText("Hello " + userName);
				
				totalApplications=0;
				totalSelected=0;
				totalNotSelected=0;
				totalInProgress=0;
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String sqlLogin = "SELECT * FROM applications" +" WHERE applicantID="+userID+";";
					ResultSet rs = stmt.executeQuery(sqlLogin);
					rs = stmt.executeQuery(sqlLogin);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlLogin);
						while(rs.next()){
							if(rs.getInt("applicantSelected")==0)
								totalInProgress=totalInProgress+1;
							else if(rs.getInt("applicantSelected")==1)
								totalSelected=totalSelected+1;
							else if(rs.getInt("applicantSelected")==2)
								totalNotSelected=totalNotSelected+1;
							totalApplications=totalInProgress+totalSelected+totalNotSelected;
							}
						}
					conn.close();
				} catch (SQLException errorSQL) {
				}
				totalAppliedBoxDashboard.add(totalAppliedLabel2);
				totalAppliedBoxDashboard.add(totalAppliedLabel1);
				totalAppliedCountDashboard.setText(totalApplications+"");
				totalAppliedBoxDashboard.add(totalAppliedCountDashboard);
				Fullpanel.add(totalAppliedBoxDashboard);
				
				inProgressBoxDashboard.add(inProgressLabel1);
				inProgressBoxDashboard.add(inProgressLabel2);
				inProgressBoxCountDashboard.setText(totalInProgress+"");
				inProgressBoxDashboard.add(inProgressBoxCountDashboard);
				Fullpanel.add(inProgressBoxDashboard);
				
				notSelectedBoxDashboard.add(notSelectedLabel1);
				notSelectedBoxDashboard.add(notSelectedLabel2);
				notSelectedBoxCountDashboard.setText(totalNotSelected+"");
				notSelectedBoxDashboard.add(notSelectedBoxCountDashboard);
				Fullpanel.add(notSelectedBoxDashboard);
				
				selectedBoxDashboard.add(selectedLabel1);
				selectedBoxDashboard.add(selectedLabel2);
				selectedBoxCountDashboard.setText(totalSelected+"");
				selectedBoxDashboard.add(selectedBoxCountDashboard);
				Fullpanel.add(selectedBoxDashboard);
			}
		});
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shweta.rn\\Downloads\\Untitled design (18).gif"));
		lblNewLabel.setBounds(0, 0, 1280, 720);
		contentPane.add(lblNewLabel);
	}
}
