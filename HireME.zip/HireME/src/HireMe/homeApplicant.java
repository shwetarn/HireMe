package HireMe;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.SwingConstants;

public class homeApplicant extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
	public static String DB_URL = "jdbc:mysql://localhost/firstTry";
	public static String USER = "root";
	public static String PASS = "root";
	
	
	public static String userID=-1+"";
	public static String userEMail="";
	public static String userName="";
	public static String phoneNumber="";
	public static String password="";
	
	int totalApplications=0;
	int totalSelected=0;
	int totalNotSelected=0;
	int totalInProgress=0;
	public static ArrayList<String> companyN=new ArrayList<String>();
	public static ArrayList<String> jobN=new ArrayList<String>();
	public static ArrayList<Object> assessmentInfo=new ArrayList<Object>();
	private JTextField userNameValue,eMailValue,phoneNumberValue;
	private JTextField passwordValue, confirmPasswordValue;
	
	public static void applyForJob(String indexJob) {
		ArrayList<Object> temp=new ArrayList<Object>();
		try(Connection connect = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmtect = connect.createStatement();
			String companyName="select * from availableVacancy where ID="+indexJob+";";
			ResultSet rsect = stmtect.executeQuery(companyName);
			while(rsect.next()) {
				temp.add(rsect.getString("questionOne"));
				temp.add(rsect.getString("questionTwo"));
				temp.add(rsect.getString("questionThree"));
				temp.add(rsect.getString("questionFour"));
				temp.add(rsect.getString("questionFive"));
				temp.add(rsect.getString("answerOne"));
				temp.add(rsect.getString("answerTwo"));
				temp.add(rsect.getString("answerThree"));
				temp.add(rsect.getString("answerFour"));
				temp.add(rsect.getString("answerFive"));
				temp.add(rsect.getString("optionsOne"));
				temp.add(rsect.getString("optionsTwo"));
				temp.add(rsect.getString("optionsThree"));
				temp.add(rsect.getString("optionsFour"));
				temp.add(rsect.getString("optionsFive"));
				temp.add(rsect.getString("companyID"));
				temp.add(indexJob);
				assessmentInfo=temp;
				}
			connect.close();
		} catch (SQLException errorSQL) {
		}
//		vacancyTableApplied vacancyTableAppliedAssessment = new vacancyTableApplied();
//		vacancyTableAppliedAssessment.userID=userID;
//		vacancyTableAppliedAssessment.userEMail=userEMail;
//		vacancyTableAppliedAssessment.userName=userName;
//		vacancyTableAppliedAssessment.phoneNumber=phoneNumber;
////		vacancyTableAppliedAssessment.abc(indexJob);
//		vacancyTableAppliedAssessment.displayInfo(indexJob);
//		vacancyTableAppliedAssessment.main(null);
		}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					homeApplicant frame = new homeApplicant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public static void companyNameFunc() {
		companyN.clear();
		try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmt = conn.createStatement();
			String companyName="select * from companyInfo;";
			ResultSet rs = stmt.executeQuery(companyName);
			while(rs.next()) {
				companyN.add(rs.getString("companyID")+rs.getString("companyName"));
				}
			conn.close();
		} catch (SQLException errorSQL) {
		}
	}
	
	public static void jobNameFunc() {
		jobN.clear();
		try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmt = conn.createStatement();
			String availableVacancy="select * from availableVacancy;";
			ResultSet rs = stmt.executeQuery(availableVacancy);
			while(rs.next()) {
				jobN.add(rs.getString("ID")+rs.getString("jobTitle"));
				}
			conn.close();
		} catch (SQLException errorSQL) {
		}
	}
	
	public homeApplicant() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 694, 612);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel profilePanel = new JPanel();
		profilePanel.setBackground(new Color(255, 255, 255, 200));
		profilePanel.setBounds(120, 150, 500, 450);
		
		JPanel Fullpanel = new JPanel();
		Fullpanel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		Fullpanel.setBounds(350, 0, 1400, 720);
		contentPane.add(Fullpanel);
		Fullpanel.setLayout(null);
		Fullpanel.setOpaque(false);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		panel.setBounds(0, 0, 350, 720);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel hireMeLogo = new JLabel("HIRE!ME");
		hireMeLogo.setBounds(1155, 10, 1280, 30);
		hireMeLogo.setForeground(Color.WHITE);
		hireMeLogo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(hireMeLogo);
		
		JLabel pageTitle = new JLabel("Applicant Dashboard");
		pageTitle.setBounds(365, 20, 800, 40);
		pageTitle.setFont(new Font("Tahoma", Font.PLAIN, 34));
		contentPane.add(pageTitle);
		
		JLabel userNameTitle = new JLabel("Hello " + userName);
		userNameTitle.setBounds(365, 70, 400, 40);
		userNameTitle.setFont(new Font("Tahoma", Font.PLAIN, 24));
		contentPane.add(userNameTitle);
		
		try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
			Statement stmt = conn.createStatement();
			String sqlLogin = "SELECT * FROM applications" +" WHERE applicantID="+userID+";";
			ResultSet rs = stmt.executeQuery(sqlLogin);
			rs = stmt.executeQuery(sqlLogin);
			if(rs.next())
			{
				rs = stmt.executeQuery(sqlLogin);
				while(rs.next()){
					if(rs.getInt("applicantSelected")==0)
						totalInProgress=totalInProgress+1;
					else if(rs.getInt("applicantSelected")==1)
						totalSelected=totalSelected+1;
					else if(rs.getInt("applicantSelected")==2)
						totalNotSelected=totalNotSelected+1;
					totalApplications=totalInProgress+totalSelected+totalNotSelected;
					}
				}
			conn.close();
		} catch (SQLException errorSQL) {
		}
		
		JPanel totalAppliedBoxDashboard = new JPanel();
		totalAppliedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		totalAppliedBoxDashboard.setBounds(20, 201, 255, 155);
		Fullpanel.add(totalAppliedBoxDashboard);
		totalAppliedBoxDashboard.setLayout(null);
		
		JLabel totalAppliedLabel1 = new JLabel("Total");
		JLabel totalAppliedLabel2 = new JLabel("Applied");
		totalAppliedLabel1.setBounds(15, 5, 400, 35);
		totalAppliedLabel2.setBounds(15, 30, 400, 35);
		totalAppliedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		totalAppliedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		totalAppliedLabel1.setForeground(Color.WHITE);
		totalAppliedLabel2.setForeground(Color.WHITE);
		totalAppliedBoxDashboard.add(totalAppliedLabel2);
		totalAppliedBoxDashboard.add(totalAppliedLabel1);
		
		JLabel totalAppliedCountDashboard = new JLabel(totalApplications+"");
		totalAppliedCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		totalAppliedCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		totalAppliedCountDashboard.setForeground(new Color(255, 255, 255));
		totalAppliedCountDashboard.setBounds(152, 62, 133, 103);
		totalAppliedBoxDashboard.add(totalAppliedCountDashboard);
		
		JPanel inProgressBoxDashboard = new JPanel();
		inProgressBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		inProgressBoxDashboard.setBounds(20, 401, 255, 155);
		Fullpanel.add(inProgressBoxDashboard);
		inProgressBoxDashboard.setLayout(null);
		
		JLabel inProgressLabel1 = new JLabel("In");
		JLabel inProgressLabel2 = new JLabel("Progress");
		inProgressLabel1.setBounds(15, 5, 400, 35);
		inProgressLabel2.setBounds(15, 30, 400, 35);
		inProgressLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		inProgressLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		inProgressLabel1.setForeground(Color.WHITE);
		inProgressLabel2.setForeground(Color.WHITE);
		inProgressBoxDashboard.add(inProgressLabel1);
		inProgressBoxDashboard.add(inProgressLabel2);
		
		JLabel inProgressBoxCountDashboard = new JLabel(totalInProgress+"");
		inProgressBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		inProgressBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		inProgressBoxCountDashboard.setForeground(new Color(255, 255, 255));
		inProgressBoxCountDashboard.setBounds(152, 62, 133, 103);
		inProgressBoxDashboard.add(inProgressBoxCountDashboard);
		
		JPanel notSelectedBoxDashboard = new JPanel();
		notSelectedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		notSelectedBoxDashboard.setBounds(580, 201, 255, 155);
		Fullpanel.add(notSelectedBoxDashboard);
		notSelectedBoxDashboard.setLayout(null);
		
		JLabel notSelectedLabel1 = new JLabel("Not");
		JLabel notSelectedLabel2 = new JLabel("Selected");
		notSelectedLabel1.setBounds(15, 5, 400, 35);
		notSelectedLabel2.setBounds(15, 30, 400, 35);
		notSelectedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		notSelectedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		notSelectedLabel1.setForeground(Color.WHITE);
		notSelectedLabel2.setForeground(Color.WHITE);
		notSelectedBoxDashboard.add(notSelectedLabel1);
		notSelectedBoxDashboard.add(notSelectedLabel2);
		
		JLabel notSelectedBoxCountDashboard = new JLabel(totalNotSelected+"");
		notSelectedBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		notSelectedBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		notSelectedBoxCountDashboard.setForeground(new Color(255, 255, 255));
		notSelectedBoxCountDashboard.setBounds(152, 62, 133, 103);
		notSelectedBoxDashboard.add(notSelectedBoxCountDashboard);
		notSelectedBoxDashboard.setLayout(null);
		
		JPanel selectedBoxDashboard = new JPanel();
		selectedBoxDashboard.setBackground(new Color(0, 0, 0, 100));
		selectedBoxDashboard.setBounds(300, 201, 255, 155);
		Fullpanel.add(selectedBoxDashboard);
		
		JLabel selectedLabel1 = new JLabel("Total");
		JLabel selectedLabel2 = new JLabel("Selected");
		selectedLabel1.setBounds(15, 5, 400, 35);
		selectedLabel2.setBounds(15, 30, 400, 35);
		selectedLabel1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		selectedLabel2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		selectedLabel1.setForeground(Color.WHITE);
		selectedLabel2.setForeground(Color.WHITE);
		selectedBoxDashboard.add(selectedLabel1);
		selectedBoxDashboard.add(selectedLabel2);
		
		JLabel selectedBoxCountDashboard = new JLabel(totalSelected+"");
		selectedBoxCountDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		selectedBoxCountDashboard.setFont(new Font("Tahoma", Font.PLAIN, 50));
		selectedBoxCountDashboard.setForeground(new Color(255, 255, 255));
		selectedBoxCountDashboard.setBounds(152, 62, 133, 103);
		selectedBoxDashboard.add(selectedBoxCountDashboard);
		selectedBoxDashboard.setLayout(null);
		
		JButton dashboardBtn = new JButton("DASHBOARD");
		JButton communityWallBtn = new JButton("COMMUNITY WALL");
		JButton totalAppliedBtn = new JButton("APPLIED VACANCIES");
		JButton inProgressBtn = new JButton("IN PROGRESS VACANCIES");
		JButton selectedBtn = new JButton("SELECTED VACANCIES");
		JButton userProfileBtn = new JButton("PROFILE");
		
		
		JButton applyBtn = new JButton("APPLY");
		applyBtn.setBackground(new Color(0, 0, 0, 80));
		applyBtn.setForeground(Color.white);
		applyBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		applyBtn.setBounds(0,240,350,40);
		panel.add(applyBtn);
		
		JPanel textgrid = new JPanel();
		GridLayout gl=new GridLayout(100,100);
		textgrid.setLayout(gl);
		
		JScrollPane jp=new JScrollPane(textgrid,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp.setBounds(20, 201,900,419);
		
		String [] header={"Job Title","Application Status","View Score Details","Company Name"};
        String [][] data = null;
        
        DefaultTableModel model = new DefaultTableModel(data,header);
        JTable table = new JTable(model);
        JScrollPane js=new JScrollPane(table);
        table.setPreferredScrollableViewportSize(new Dimension(450,63));
        table.setFillsViewportHeight(true);
        table.setRowHeight(20);
        js.setBackground(new Color(0,0,0,100));
        table.setBackground(new Color(0,0,0,0));
        table.setForeground(Color.white);
		
		
		applyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);Fullpanel.remove(js);
				textgrid.removeAll();
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
				
				Fullpanel.remove(totalAppliedBoxDashboard);
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				textgrid.setOpaque(true);
				textgrid.setBackground(new Color(100,100,100,80));
				textgrid.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
				jp.setOpaque(true);
				jp.setBackground(new Color(100,100,100,0));
				jp.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
				textgrid.removeAll();
				Fullpanel.add(jp);
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String QUERY = "SELECT * FROM availableVacancy;";
					ResultSet rs = stmt.executeQuery(QUERY);
					String sqlaa = "SELECT * FROM availableVacancy;";
					System.out.println("sqlaa"+sqlaa);
					rs = stmt.executeQuery(sqlaa);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlaa);
						while(rs.next()){
							JLabel jobTitle = new JLabel("     "+rs.getString("jobTitle"));
//							jobTitle.setHorizontalAlignment(SwingConstants.CENTER);
							jobTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
							jobTitle.setForeground(Color.white);
							
							JLabel vacancyType = new JLabel("     Vacancy Type: "+rs.getString("vacancyType"));
							vacancyType.setFont(new Font("Tahoma", Font.PLAIN, 15));
							vacancyType.setForeground(Color.white);
							
							JLabel dateOfJoining = new JLabel("     Date of Joining: "+rs.getString("dateOfJoining"));
							dateOfJoining.setFont(new Font("Tahoma", Font.PLAIN, 15));
							dateOfJoining.setForeground(Color.white);
							
//							JLabel applyBtnJob = new JLabel("     Apply Job ID "+rs.getString("ID"));
//							applyBtnJob.setFont(new Font("Tahoma", Font.PLAIN, 17));
							String companyNameTemp="";
	    					companyNameFunc();
	    					for(int index=0;index<companyN.size();index++) {
	    						if(companyN.get(index).contains(rs.getString("companyID")))
	    							{
	    							companyNameTemp=companyN.get(index).substring(6);
	    							}
	    					}
	    					
	    					JLabel companyName = new JLabel("     Vacancy created by : "+companyNameTemp);
	    					companyName.setFont(new Font("Tahoma", Font.PLAIN, 15));
	    					companyName.setForeground(Color.white);
	    					
							JButton applyBtnJob = new JButton("APPLY Job ID "+ rs.getString("ID"));
							applyBtnJob.setOpaque(false);applyBtnJob.setBackground(new Color(0,0,0,0));
							applyBtnJob.setForeground(Color.white);
							applyBtnJob.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									String indexTemp=applyBtnJob.getLabel();
									indexTemp=indexTemp.substring(13);
									System.out.println("indexTemp"+indexTemp);
									applyForJob(indexTemp);
									model.setRowCount(0);Fullpanel.remove(js);
									textgrid.removeAll();
									Fullpanel.remove(totalAppliedBoxDashboard);
									totalAppliedBoxDashboard.remove(totalAppliedLabel2);
									totalAppliedBoxDashboard.remove(totalAppliedLabel1);
									totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
									
									Fullpanel.remove(inProgressBoxDashboard);
									inProgressBoxDashboard.remove(inProgressLabel1);
									inProgressBoxDashboard.remove(inProgressLabel2);
									inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
									
									Fullpanel.remove(notSelectedBoxDashboard);
									notSelectedBoxDashboard.remove(notSelectedLabel1);
									notSelectedBoxDashboard.remove(notSelectedLabel2);
									notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
									
									Fullpanel.remove(selectedBoxDashboard);
									selectedBoxDashboard.remove(selectedLabel1);
									selectedBoxDashboard.remove(selectedLabel2);
									selectedBoxDashboard.remove(selectedBoxCountDashboard);
									textgrid.setOpaque(true);
									textgrid.setBackground(new Color(100,100,100,80));
									textgrid.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
									jp.setOpaque(true);
									jp.setBackground(new Color(100,100,100,0));
									jp.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
									textgrid.removeAll();
									Fullpanel.add(jp);
									
									
									pageTitle.setText("ASSESSMENT");
									applyBtn.setOpaque(false);
									dashboardBtn.setOpaque(true);
									totalAppliedBtn.setOpaque(true);
									communityWallBtn.setOpaque(true);
									selectedBtn.setOpaque(true);
									applyBtn.setForeground(Color.black);
									
									ArrayList<Object> tempSend=new ArrayList<Object>();
			    					tempSend.add(assessmentInfo.get(16)+"");
			    					tempSend.add(userID);
			    					System.out.println("tempSend"+tempSend);
			    					JDBCconnection connect=new JDBCconnection();
			    					boolean applicantApplied = connect.applicantLogin(tempSend,"findApplicantAppliedBool");
			    					if(applicantApplied) {
			    						JOptionPane.showMessageDialog(contentPane, "Already Applied!");
			    					}
			    					else {
			    						String answerOne=assessmentInfo.get(5)+"";
					            		String answerTwo=assessmentInfo.get(6)+"";
					            		String answerThree=assessmentInfo.get(7)+"";
					            		String answerFour=assessmentInfo.get(8)+"";
					            		String answerFive=assessmentInfo.get(9)+"";
										
										JLabel questionONE = new JLabel("1. "+assessmentInfo.get(0)+"");
										questionONE.setFont(new Font("Tahoma", Font.PLAIN, 18));
										textgrid.add(questionONE);
										System.out.println("assessmentInfo"+assessmentInfo);
										String tempOptions=assessmentInfo.get(10)+"";
										String[] optionOne = tempOptions.split(",");
					            		JRadioButton rb1,rb2;    
					            		rb1=new JRadioButton(optionOne[0]);    
//					            		rb1.setBounds(100,50,100,30);      
					            		rb2=new JRadioButton(optionOne[1]);    
//					            		rb2.setBounds(100,100,100,30);    
					            		ButtonGroup bg=new ButtonGroup();    
					            		bg.add(rb1);bg.add(rb2);
					            		rb1.setOpaque(false);
					            		rb2.setOpaque(false);
					            		textgrid.add(rb1);
					            		textgrid.add(rb2);
					            		
					            		JLabel spacelINE2 = new JLabel("     ");
					            		textgrid.add(spacelINE2);
										
										
										JLabel questionTWO = new JLabel("2. "+assessmentInfo.get(1)+"");
										questionTWO.setFont(new Font("Tahoma", Font.PLAIN, 18));
										textgrid.add(questionTWO);
										
										tempOptions=assessmentInfo.get(11)+"";
										String[] optionTwo = tempOptions.split(",");
					            		JRadioButton o21,o22;    
					            		o21=new JRadioButton(optionTwo[0]);    
//					            		o21.setBounds(100,50,100,30);      
					            		o22=new JRadioButton(optionTwo[1]);    
//					            		o22.setBounds(100,100,100,30);    
					            		ButtonGroup back2=new ButtonGroup();    
					            		back2.add(o21);back2.add(o22);
					            		o21.setOpaque(false);
					            		o22.setOpaque(false);
					            		textgrid.add(o21);
					            		textgrid.add(o22);
					            		
					            		JLabel spacelINE3 = new JLabel("     ");
					            		textgrid.add(spacelINE3);
										
										JLabel questionTHREE = new JLabel("3. "+assessmentInfo.get(2)+"");
										questionTHREE.setFont(new Font("Tahoma", Font.PLAIN, 18));
										textgrid.add(questionTHREE);
										
										tempOptions=assessmentInfo.get(12)+"";
					            		String[] optionThree = tempOptions.split(",");
					            		JRadioButton o31,o32;    
					            		o31=new JRadioButton(optionThree[0]);    
					            		o31.setBounds(100,50,100,30);      
					            		o32=new JRadioButton(optionThree[1]);    
					            		o32.setBounds(100,100,100,30);    
					            		ButtonGroup back3=new ButtonGroup();    
					            		back3.add(o31);back2.add(o32);
					            		o31.setOpaque(false);
					            		o32.setOpaque(false);
					            		textgrid.add(o31);
					            		textgrid.add(o32);
					            		
					            		JLabel spacelINE4 = new JLabel("     ");
					            		textgrid.add(spacelINE4);
										
										JLabel questionFOUR = new JLabel("4. "+assessmentInfo.get(3)+"");
										questionFOUR.setFont(new Font("Tahoma", Font.PLAIN, 18));
										textgrid.add(questionFOUR);
										
										tempOptions=assessmentInfo.get(13)+"";
					            		String[] optionFour = tempOptions.split(",");
					            		JRadioButton o41,o42;    
					            		o41=new JRadioButton(optionFour[0]);    
					            		o41.setBounds(100,50,100,30);      
					            		o42=new JRadioButton(optionFour[1]);    
					            		o42.setBounds(100,100,100,30);    
					            		ButtonGroup back4=new ButtonGroup();    
					            		back4.add(o41);back4.add(o42);
					            		o41.setOpaque(false);
					            		o42.setOpaque(false);
					            		textgrid.add(o41);
					            		textgrid.add(o42);

					            		JLabel spacelINE5 = new JLabel("     ");
					            		textgrid.add(spacelINE5);
										
										JLabel questionFIVE = new JLabel("5. "+assessmentInfo.get(4)+"");
										questionFIVE.setFont(new Font("Tahoma", Font.PLAIN, 18));
										textgrid.add(questionFIVE);
										
										tempOptions=assessmentInfo.get(14)+"";
										String[] optionFive = tempOptions.split(",");
					            		JRadioButton o51,o52;    
					            		o51=new JRadioButton(optionFive[0]);    
					            		o51.setBounds(100,50,100,30);      
					            		o52=new JRadioButton(optionFive[1]);    
					            		o52.setBounds(100,100,100,30);    
					            		ButtonGroup back5=new ButtonGroup();    
					            		back5.add(o51);back5.add(o52);
					            		o51.setOpaque(false);
					            		o52.setOpaque(false);
					            		textgrid.add(o51);
					            		textgrid.add(o52);
					            		
					            		JLabel spacelINE = new JLabel("     ");
					            		textgrid.add(spacelINE);
					            		JButton submitAssessment=new JButton("Submit Assessment");    
					            		submitAssessment.setBounds(100,100,100, 40);
					            		submitAssessment.setBackground(new Color(56, 120, 211, 100));
					            		submitAssessment.addActionListener(new ActionListener() {
					            			public void actionPerformed(ActionEvent e) {
					            				int counterMarks=0;
					            				if(rb1.isSelected() && answerOne.equals("1"))
					            					counterMarks=counterMarks+1;
					            				else if (rb2.isSelected() && answerOne.equals("2"))
					        					counterMarks=counterMarks+1;
					            				
					            				if(o21.isSelected() && answerTwo.equals("1"))
					            					counterMarks=counterMarks+1;
					            				else if (o22.isSelected() && answerTwo.equals("2"))
					        					counterMarks=counterMarks+1;
					            				
					            				if(o31.isSelected() && answerThree.equals("1"))
					            					counterMarks=counterMarks+1;
					            				else if (o32.isSelected() && answerThree.equals("2"))
					        					counterMarks=counterMarks+1;
					            				
					            				if(o41.isSelected() && answerFour.equals("1"))
					            					counterMarks=counterMarks+1;
					            				else if (o42.isSelected() && answerFour.equals("2"))
					        					counterMarks=counterMarks+1;
					            				
					            				if(o51.isSelected() && answerFive.equals("1"))
					            					counterMarks=counterMarks+1;
					            				else if (o52.isSelected() && answerFive.equals("2"))
					        					counterMarks=counterMarks+1;
					            				
					            				System.out.println("counterMarks "+counterMarks);
					            				ArrayList<Object> temp=new ArrayList<Object>();
									            	temp.add("Applied");
									            	temp.add(assessmentInfo.get(16));
									            	temp.add(userID);
									            	temp.add(assessmentInfo.get(15));
									            	temp.add(0+"");
									            	temp.add(counterMarks+"");
									            	JDBCconnection jdbc_co = new JDBCconnection();
									            	boolean success = jdbc_co.applicantLogin(temp, "addNewApplication");
									            	if(success) {
									            		viewApplicationDetails viewApplicationDetailsHome=new viewApplicationDetails();
														dispose();
														viewApplicationDetailsHome.main(null);
									            	}
					            			}
					            		});
					            		textgrid.add(submitAssessment);
					            		JLabel spaceLine = new JLabel("\n");
					            		spaceLine.setFont(new Font("Imprint MT Shadow", Font.BOLD, 14));
					            		textgrid.add(spaceLine);
	
			    					}
									
																	}
							});
							
							JLabel spaceLine = new JLabel("     ");
							spaceLine.setFont(new Font("Tahoma", Font.PLAIN, 18));
							textgrid.add(jobTitle);
							textgrid.add(vacancyType);
							textgrid.add(dateOfJoining);
							textgrid.add(companyName);
							textgrid.add(applyBtnJob);
							textgrid.add(spaceLine);
		                }
		           }
		           conn.close();
				} catch (SQLException errorSQL) {
		       	errorSQL.printStackTrace();
		       	}
				
				pageTitle.setText("JOB VACANCIES AVAILABLE");
				applyBtn.setOpaque(false);
				dashboardBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				applyBtn.setForeground(Color.black);
			}
		});
		
		inProgressBtn.setBackground(new Color(0, 0, 0, 80));
		inProgressBtn.setForeground(Color.white);
		inProgressBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		inProgressBtn.setBounds(0,320,350,40);
		panel.add(inProgressBtn);
		
		selectedBtn.setBackground(new Color(0, 0, 0, 80));
		selectedBtn.setForeground(Color.white);
		selectedBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		selectedBtn.setBounds(0,360,350,40);
		panel.add(selectedBtn);
		
		userProfileBtn.setBackground(new Color(0, 0, 0, 80));
		userProfileBtn.setForeground(Color.white);
		userProfileBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		userProfileBtn.setBounds(0,440,350,40);
		panel.add(userProfileBtn);
		
		totalAppliedBtn.setBackground(new Color(0, 0, 0, 80));
		totalAppliedBtn.setForeground(Color.white);
		totalAppliedBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		totalAppliedBtn.setBounds(0,280,350,40);
		panel.add(totalAppliedBtn);
		
		userProfileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				Fullpanel.remove(js);
//				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
//					Statement stmt = conn.createStatement();
//					String companyName="select * from companyInfo;";
//					ResultSet rs = stmt.executeQuery(companyName);
//					while(rs.next()) {
//						companyN.add(rs.getString("companyID")+rs.getString("companyName"));
//						}
//					conn.close();
//	    		} catch (SQLException errorSQL) {
//	    		}

		        
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				profilePanel.removeAll();
				Fullpanel.add(profilePanel);
				profilePanel.setLayout(null);
//				JLabel panelLabel = new JLabel("REGISTER AS APPLICANT - HIRE!ME");
//				panelLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
//				panelLabel.setHorizontalAlignment(SwingConstants.CENTER);
//				panelLabel.setBounds(0, 14, 500, 19);
//				panel.add(panelLabel);

				JLabel phoneNumberLabel = new JLabel("Phone Number");
				phoneNumberLabel.setBounds(25, 216, 200, 30);
				phoneNumberValue = new JTextField();
				phoneNumberValue.setBounds(150, 216, 320, 30);
				phoneNumberValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
				phoneNumberValue.setOpaque(false);
				phoneNumberValue.setText(phoneNumber);
				profilePanel.add(phoneNumberLabel);
				profilePanel.add(phoneNumberValue);
				
				JLabel eMailLabel = new JLabel("E Mail");
				eMailLabel.setBounds(25, 156, 200, 30);
				eMailValue = new JTextField();
				eMailValue.setBounds(150, 156, 320, 30);
				eMailValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
				eMailValue.setOpaque(false);
				profilePanel.add(eMailLabel);
				profilePanel.add(eMailValue);
				eMailValue.setText(userEMail);
				
				JLabel passwordLabel = new JLabel("PASSWORD");
				passwordLabel.setBounds(25, 276, 200, 30);
				passwordValue = new JTextField();
				passwordValue.setBounds(150, 276, 320, 30);
				passwordValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
				passwordValue.setOpaque(false);
				profilePanel.add(passwordLabel);
				profilePanel.add(passwordValue);
				passwordValue.setText(password);
				
				JLabel userNameLabel = new JLabel("APPLICANT NAME");
				userNameLabel.setBounds(25, 96, 200, 30);
				userNameValue = new JTextField();
				userNameValue.setBounds(150, 96, 320, 30);
				userNameValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
				userNameValue.setOpaque(false);
				profilePanel.add(userNameLabel);
				profilePanel.add(userNameValue);
				userNameValue.setText(userName);
				
				JButton registerApp = new JButton("UPDATE APPLICANT DETAILS");
				registerApp.setBackground(new Color(0, 0, 0, 80));
				registerApp.setForeground(Color.white);
				registerApp.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
				registerApp.setBounds(25, 406, 450, 30);
				profilePanel.add(registerApp);
				
				registerApp.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						ArrayList<Object> temp=new ArrayList<Object>();
						temp.add(userNameValue.getText());
						temp.add(eMailValue.getText());
//						temp.add(eMailValue.getText());
						temp.add(phoneNumberValue.getText());
						temp.add(passwordValue.getText());
						temp.add(userID);
						JDBCconnection connect=new JDBCconnection();
    					boolean applicantupdated = connect.applicantLogin(temp,"updateApplicantAllDetails");
    					if(applicantupdated) {
    						viewApplicationDetails viewApplicationDetailsHome=new viewApplicationDetails();
							dispose();
							viewApplicationDetailsHome.main(null);
    					}
					}
				});
				
				
				pageTitle.setText("PROFILE");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				inProgressBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				userProfileBtn.setOpaque(false);
				userProfileBtn.setForeground(Color.black);
				textgrid.removeAll();
//		        js.setVisible(true);
//		        js.setBounds(20, 201,900,419);
//		        Fullpanel.add(js);
		        
				
			}
		});
		
		inProgressBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				Fullpanel.remove(js);
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
//				vacancyTableApplied vacancyTableApplied=new vacancyTableApplied();
//				vacancyTableApplied.userID=userID;
//				vacancyTableApplied.userName=userName;
//				vacancyTableApplied.userEMail=userEMail;
//				vacancyTableApplied.phoneNumber=phoneNumber;
//				vacancyTableApplied.main(null);
				
				
				companyNameFunc();
				jobNameFunc();
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
	    			Statement stmt = conn.createStatement();
	    			
	    			String applicantAppliedDetails ="Select * from applications where applicantID="+userID+";";
	    			System.out.println("applicantAppliedDetails"+applicantAppliedDetails);
//	    			String companyName="select * from companyInfo;";
	    			ResultSet rs = stmt.executeQuery(applicantAppliedDetails);
	    			rs = stmt.executeQuery(applicantAppliedDetails);
	    			model.setRowCount(0);
	    			if(rs.next())
	    			{
	    				rs = stmt.executeQuery(applicantAppliedDetails);
	    				int i=0;
	    				while(rs.next()){
	    					String companyNameTemp="";
	    					String jobNameTemp="";
	    					for(int index=0;index<companyN.size();index++) {
	    						if(companyN.get(index).contains(rs.getString("companyID")))
	    							{
	    							companyNameTemp=companyN.get(index).substring(6);
	    							}
	    					}
	    					for(int index=0;index<jobN.size();index++) {
	    						boolean doubleDigit=false;
	    						if(rs.getString("jobID").length()>1)
	    							doubleDigit=true;
	    						if(jobN.get(index).contains(rs.getString("jobID")))
	    							{
	    							if(doubleDigit)
	    								jobNameTemp=jobN.get(index).substring(2);
	    							}
	    						else
	    							jobNameTemp=jobN.get(index).substring(1);
	    					}
	    					if(rs.getString("applicantSelected").equals("0"))
	    						model.addRow(new Object[]{jobNameTemp,rs.getString("applicationStatus"),rs.getString("score"),companyNameTemp});
//	    					String []temp={rs.getString("jobID"),rs.getString("applicationStatus"),rs.getString("score"),rs.getString("companyID")};
//	    					data[i]=temp;
	    					i=i+1;
	    					}
	    				}
	    			conn.close();
	    		} catch (SQLException errorSQL) {
	    		}

		        
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("IN PROGRESS VACANCIES");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				userProfileBtn.setOpaque(true);
				inProgressBtn.setOpaque(false);
				inProgressBtn.setForeground(Color.black);
				textgrid.removeAll();
		        js.setVisible(true);
		        js.setBounds(20, 201,900,419);
		        Fullpanel.add(js);
		        
				
			}
		});
		
		selectedBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				Fullpanel.remove(js);
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
//				vacancyTableApplied vacancyTableApplied=new vacancyTableApplied();
//				vacancyTableApplied.userID=userID;
//				vacancyTableApplied.userName=userName;
//				vacancyTableApplied.userEMail=userEMail;
//				vacancyTableApplied.phoneNumber=phoneNumber;
//				vacancyTableApplied.main(null);
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String companyName="select * from companyInfo;";
					ResultSet rs = stmt.executeQuery(companyName);
					while(rs.next()) {
						companyN.add(rs.getString("companyID")+rs.getString("companyName"));
						}
					conn.close();
	    		} catch (SQLException errorSQL) {
	    		}
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String availableVacancy="select * from availableVacancy;";
					ResultSet rs = stmt.executeQuery(availableVacancy);
					while(rs.next()) {
						jobN.add(rs.getString("ID")+rs.getString("jobTitle"));
						}
					conn.close();
	    		} catch (SQLException errorSQL) {
	    		}
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
	    			Statement stmt = conn.createStatement();
	    			
	    			String applicantAppliedDetails ="Select * from applications where applicantID="+userID+";";
	    			System.out.println("applicantAppliedDetails"+applicantAppliedDetails);
//	    			String companyName="select * from companyInfo;";
	    			ResultSet rs = stmt.executeQuery(applicantAppliedDetails);
	    			rs = stmt.executeQuery(applicantAppliedDetails);
	    			model.setRowCount(0);
	    			if(rs.next())
	    			{
	    				rs = stmt.executeQuery(applicantAppliedDetails);
	    				int i=0;
	    				while(rs.next()){
	    					String companyNameTemp="";
	    					String jobNameTemp="";
	    					for(int index=0;index<companyN.size();index++) {
	    						if(companyN.get(index).contains(rs.getString("companyID")))
	    							{
	    							companyNameTemp=companyN.get(index).substring(6);
	    							}
	    					}
	    					for(int index=0;index<jobN.size();index++) {
	    						boolean doubleDigit=false;
	    						if(rs.getString("jobID").length()>1)
	    							doubleDigit=true;
	    						if(jobN.get(index).contains(rs.getString("jobID")))
	    							{
	    							if(doubleDigit)
	    								jobNameTemp=jobN.get(index).substring(2);
	    							}
	    						else
	    							jobNameTemp=jobN.get(index).substring(1);
	    					}
	    					if(rs.getString("applicantSelected").equals("1"))
	    						model.addRow(new Object[]{jobNameTemp,rs.getString("applicationStatus"),rs.getString("score"),companyNameTemp});
//	    					String []temp={rs.getString("jobID"),rs.getString("applicationStatus"),rs.getString("score"),rs.getString("companyID")};
//	    					data[i]=temp;
	    					i=i+1;
	    					}
	    				}
	    			conn.close();
	    		} catch (SQLException errorSQL) {
	    		}

		        
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("IN PROGRESS VACANCIES");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				inProgressBtn.setOpaque(true);
				userProfileBtn.setOpaque(true);
				selectedBtn.setOpaque(false);
				selectedBtn.setForeground(Color.black);
				textgrid.removeAll();
		        js.setVisible(true);
		        js.setBounds(20, 201,900,419);
		        Fullpanel.add(js);
		        
				
			}
		});



		
		totalAppliedBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				Fullpanel.remove(js);
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
//				vacancyTableApplied vacancyTableApplied=new vacancyTableApplied();
//				vacancyTableApplied.userID=userID;
//				vacancyTableApplied.userName=userName;
//				vacancyTableApplied.userEMail=userEMail;
//				vacancyTableApplied.phoneNumber=phoneNumber;
//				vacancyTableApplied.main(null);
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String companyName="select * from companyInfo;";
					ResultSet rs = stmt.executeQuery(companyName);
					while(rs.next()) {
						companyN.add(rs.getString("companyID")+rs.getString("companyName"));
						}
					conn.close();
	    		} catch (SQLException errorSQL) {
	    		}
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String availableVacancy="select * from availableVacancy;";
					ResultSet rs = stmt.executeQuery(availableVacancy);
					while(rs.next()) {
						jobN.add(rs.getString("ID")+rs.getString("jobTitle"));
						}
					conn.close();
	    		} catch (SQLException errorSQL) {
	    		}
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
	    			Statement stmt = conn.createStatement();
	    			
	    			String applicantAppliedDetails ="Select * from applications where applicantID="+userID+";";
	    			System.out.println("applicantAppliedDetails"+applicantAppliedDetails);
//	    			String companyName="select * from companyInfo;";
	    			ResultSet rs = stmt.executeQuery(applicantAppliedDetails);
	    			rs = stmt.executeQuery(applicantAppliedDetails);
	    			model.setRowCount(0);
	    			if(rs.next())
	    			{
	    				rs = stmt.executeQuery(applicantAppliedDetails);
	    				int i=0;
	    				while(rs.next()){
	    					String companyNameTemp="";
	    					String jobNameTemp="";
	    					for(int index=0;index<companyN.size();index++) {
	    						if(companyN.get(index).contains(rs.getString("companyID")))
	    							{
	    							companyNameTemp=companyN.get(index).substring(6);
	    							}
	    					}
	    					for(int index=0;index<jobN.size();index++) {
	    						boolean doubleDigit=false;
	    						if(rs.getString("jobID").length()>1)
	    							doubleDigit=true;
	    						if(jobN.get(index).contains(rs.getString("jobID")))
	    							{
	    							if(doubleDigit)
	    								jobNameTemp=jobN.get(index).substring(2);
	    							}
	    						else
	    							jobNameTemp=jobN.get(index).substring(1);
	    					}
	    					model.addRow(new Object[]{jobNameTemp,rs.getString("applicationStatus"),rs.getString("score"),companyNameTemp});
//	    					String []temp={rs.getString("jobID"),rs.getString("applicationStatus"),rs.getString("score"),rs.getString("companyID")};
//	    					data[i]=temp;
	    					i=i+1;
	    					}
	    				}
	    			conn.close();
	    		} catch (SQLException errorSQL) {
	    		}

		        
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("APPLIED VACANCIES");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(false);
				inProgressBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				userProfileBtn.setOpaque(true);
				totalAppliedBtn.setForeground(Color.black);
				textgrid.removeAll();
		        js.setVisible(true);
		        js.setBounds(20, 201,900,419);
		        Fullpanel.add(js);
		        
				
			}
		});
		
		communityWallBtn.setBackground(new Color(0, 0, 0, 80));
		communityWallBtn.setForeground(Color.white);
		communityWallBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		communityWallBtn.setBounds(0,400,350,40);
		panel.add(communityWallBtn);
		communityWallBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);Fullpanel.remove(js);
				textgrid.removeAll();
				Fullpanel.remove(totalAppliedBoxDashboard);
				Fullpanel.remove(jp);
				totalAppliedBoxDashboard.remove(totalAppliedLabel2);
				totalAppliedBoxDashboard.remove(totalAppliedLabel1);
				totalAppliedBoxDashboard.remove(totalAppliedCountDashboard);
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
				
				Fullpanel.remove(inProgressBoxDashboard);
				inProgressBoxDashboard.remove(inProgressLabel1);
				inProgressBoxDashboard.remove(inProgressLabel2);
				inProgressBoxDashboard.remove(inProgressBoxCountDashboard);
				
				Fullpanel.remove(notSelectedBoxDashboard);
				notSelectedBoxDashboard.remove(notSelectedLabel1);
				notSelectedBoxDashboard.remove(notSelectedLabel2);
				notSelectedBoxDashboard.remove(notSelectedBoxCountDashboard);
				
				Fullpanel.remove(selectedBoxDashboard);
				selectedBoxDashboard.remove(selectedLabel1);
				selectedBoxDashboard.remove(selectedLabel2);
				selectedBoxDashboard.remove(selectedBoxCountDashboard);
				
				pageTitle.setText("COMMUNITY WALL");
				applyBtn.setOpaque(true);
				dashboardBtn.setOpaque(true);
				communityWallBtn.setOpaque(false);
				totalAppliedBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				inProgressBtn.setOpaque(true);
				userProfileBtn.setOpaque(true);
				communityWallBtn.setForeground(Color.black);
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String QUERY = "SELECT * FROM communityWall;";
					ResultSet rs = stmt.executeQuery(QUERY);
					String sqlaa = "SELECT * FROM communityWall;";
					System.out.println("sqlaa"+sqlaa);
					rs = stmt.executeQuery(sqlaa);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlaa);
						while(rs.next()){
							JLabel userName = new JLabel("     Posted by: "+rs.getString("userName"));
							userName.setFont(new Font("Tahoma", Font.PLAIN, 18));
							userName.setForeground(Color.white);
							
							JLabel UserType = new JLabel("     User Type: "+rs.getString("UserType"));
							UserType.setFont(new Font("Tahoma", Font.PLAIN, 15));
							UserType.setForeground(Color.white);
							
							JLabel dateOfJoining = new JLabel("     "+rs.getString("Content"));
							dateOfJoining.setFont(new Font("Tahoma", Font.PLAIN, 15));
							dateOfJoining.setForeground(Color.white);
							
							JLabel spaceLine = new JLabel("     ");
							spaceLine.setFont(new Font("Tahoma", Font.PLAIN, 18));
							
							textgrid.add(userName);
							textgrid.add(UserType);
							textgrid.add(dateOfJoining);
							
							textgrid.setOpaque(true);
							textgrid.setBackground(new Color(100,100,100,80));
							textgrid.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
							jp.setOpaque(true);
							jp.setBackground(new Color(100,100,100,0));
							jp.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
							
							if(userID.equals(rs.getString("UserID")))
							{
								JButton deletePost = new JButton("Delete Post ID "+ rs.getString("PostID"));
								deletePost.setOpaque(false);deletePost.setBackground(new Color(0,0,0,0));
								deletePost.setForeground(Color.white);
								deletePost.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										String indexTemp=deletePost.getLabel();
										indexTemp=indexTemp.substring(15);
										System.out.println("indexTemp"+indexTemp);
										try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		            					         ) {
		            			            String sql= "delete from communityWall where PostID = ?;";
		            			    		PreparedStatement st= conn.prepareStatement(sql);
		            			            st.setString(1, indexTemp);
		            			            st.executeUpdate();
		            			            conn.close();
		            			            dispose();
		            					} catch (SQLException errorSQL) {
		            		            	errorSQL.printStackTrace();
		            		            	}
									}
								});
								deletePost.setForeground(Color.RED);
								textgrid.add(deletePost);
							}
							textgrid.add(spaceLine);
							Fullpanel.add(jp);
		                }
		           }
		           conn.close();
				} catch (SQLException errorSQL) {
		       	errorSQL.printStackTrace();
		       	}
				
				
			}
		});
		
		dashboardBtn.setBackground(new Color(0, 0, 0, 80));
		dashboardBtn.setForeground(Color.white);
		dashboardBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		dashboardBtn.setBounds(0,200,350,40);
		panel.add(dashboardBtn);
		
		JButton logoutBtn = new JButton("LOGOUT");
		logoutBtn.setForeground(Color.WHITE);
		logoutBtn.setBorder(BorderFactory.createMatteBorder(0,0,0,0, Color.white));
		logoutBtn.setBackground(new Color(0, 0, 0, 80));
		logoutBtn.setBounds(0, 480, 350, 40);
		panel.add(logoutBtn);
		logoutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userID=-1+"";
				userEMail="";
				userName="";
				phoneNumber="";
				password="";
				
				totalApplications=0;
				totalSelected=0;
				totalNotSelected=0;
				totalInProgress=0;
				companyN.clear();
				jobN.clear();
				viewApplicationDetails viewApplicationDetailsHome=new viewApplicationDetails();
				dispose();
				viewApplicationDetailsHome.main(null);
			}
		});
		dashboardBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);Fullpanel.remove(js);
				textgrid.removeAll();
				applyBtn.setOpaque(true);
				Fullpanel.remove(jp);
				dashboardBtn.setOpaque(false);
				communityWallBtn.setOpaque(true);
				totalAppliedBtn.setOpaque(true);
				inProgressBtn.setOpaque(true);
				selectedBtn.setOpaque(true);
				userProfileBtn.setOpaque(true);
				dashboardBtn.setForeground(Color.black);
				profilePanel.removeAll();
				Fullpanel.remove(profilePanel);
				
				pageTitle.setText("Applicant Dashboard");
				userNameTitle.setText("Hello " + userName);
				
				totalApplications=0;
				totalSelected=0;
				totalNotSelected=0;
				totalInProgress=0;
				
				try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
					Statement stmt = conn.createStatement();
					String sqlLogin = "SELECT * FROM applications" +" WHERE applicantID="+userID+";";
					ResultSet rs = stmt.executeQuery(sqlLogin);
					rs = stmt.executeQuery(sqlLogin);
					if(rs.next())
					{
						rs = stmt.executeQuery(sqlLogin);
						while(rs.next()){
							if(rs.getInt("applicantSelected")==0)
								totalInProgress=totalInProgress+1;
							else if(rs.getInt("applicantSelected")==1)
								totalSelected=totalSelected+1;
							else if(rs.getInt("applicantSelected")==2)
								totalNotSelected=totalNotSelected+1;
							totalApplications=totalInProgress+totalSelected+totalNotSelected;
							}
						}
					conn.close();
				} catch (SQLException errorSQL) {
				}
				totalAppliedBoxDashboard.add(totalAppliedLabel2);
				totalAppliedBoxDashboard.add(totalAppliedLabel1);
				totalAppliedCountDashboard.setText(totalApplications+"");
				totalAppliedBoxDashboard.add(totalAppliedCountDashboard);
				Fullpanel.add(totalAppliedBoxDashboard);
				
				inProgressBoxDashboard.add(inProgressLabel1);
				inProgressBoxDashboard.add(inProgressLabel2);
				inProgressBoxCountDashboard.setText(totalInProgress+"");
				inProgressBoxDashboard.add(inProgressBoxCountDashboard);
				Fullpanel.add(inProgressBoxDashboard);
				
				notSelectedBoxDashboard.add(notSelectedLabel1);
				notSelectedBoxDashboard.add(notSelectedLabel2);
				notSelectedBoxCountDashboard.setText(totalNotSelected+"");
				notSelectedBoxDashboard.add(notSelectedBoxCountDashboard);
				Fullpanel.add(notSelectedBoxDashboard);
				
				selectedBoxDashboard.add(selectedLabel1);
				selectedBoxDashboard.add(selectedLabel2);
				selectedBoxCountDashboard.setText(totalSelected+"");
				selectedBoxDashboard.add(selectedBoxCountDashboard);
				Fullpanel.add(selectedBoxDashboard);
			}
		});
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shweta.rn\\Downloads\\Untitled design (18).gif"));
		lblNewLabel.setBounds(0, 0, 1280, 720);
		contentPane.add(lblNewLabel);
	}
}
