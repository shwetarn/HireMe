package HireMe;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

public class registerApplicant extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	private JTextField userNameValue,eMailValue,phoneNumberValue;
	private JTextField passwordValue, confirmPasswordValue;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registerApplicant frame = new registerApplicant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registerApplicant() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 702, 618);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("<- Go Back");
		btnNewButton.setBackground(new Color(0, 0, 0, 80));
		btnNewButton.setForeground(Color.white);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				viewApplicationDetails.userID="";
				viewApplicationDetails.userPassword="";
				viewApplicationDetails.main(null);
				dispose();
			}
		});
		btnNewButton.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
		btnNewButton.setBounds(50, 50, 100, 25);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255, 200));
//		panel.setBounds(482, 201, 350, 415);
		panel.setBounds(402, 100, 500, 500);
		contentPane.add(panel);
		panel.setLayout(null);
		JLabel panelLabel = new JLabel("REGISTER AS APPLICANT - HIRE!ME");
		panelLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panelLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panelLabel.setBounds(0, 14, 500, 19);
		panel.add(panelLabel);
		
		JLabel phoneNumberLabel = new JLabel("Phone Number");
		phoneNumberLabel.setBounds(25, 216, 200, 30);
		phoneNumberValue = new JTextField();
		phoneNumberValue.setBounds(150, 216, 320, 30);
		phoneNumberValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		phoneNumberValue.setOpaque(false);
		panel.add(phoneNumberLabel);
		panel.add(phoneNumberValue);
		
		JLabel eMailLabel = new JLabel("E Mail");
		eMailLabel.setBounds(25, 156, 200, 30);
		eMailValue = new JTextField();
		eMailValue.setBounds(150, 156, 320, 30);
		eMailValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		eMailValue.setOpaque(false);
		panel.add(eMailLabel);
		panel.add(eMailValue);
		
		JLabel passwordLabel = new JLabel("PASSWORD");
		passwordLabel.setBounds(25, 276, 200, 30);
		passwordValue = new JTextField();
		passwordValue.setBounds(150, 276, 320, 30);
		passwordValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		passwordValue.setOpaque(false);
		panel.add(passwordLabel);
		panel.add(passwordValue);
		
		JLabel confirmPasswordLabel = new JLabel("CONFIRM PASSWORD");
		confirmPasswordLabel.setBounds(25, 336, 200, 30);
		confirmPasswordValue = new JTextField();
		confirmPasswordValue.setBounds(170, 336, 300, 30);
		confirmPasswordValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		confirmPasswordValue.setOpaque(false);
		panel.add(confirmPasswordLabel);
		panel.add(confirmPasswordValue);
		
		JLabel userNameLabel = new JLabel("APPLICANT NAME");
		userNameLabel.setBounds(25, 96, 200, 30);
		userNameValue = new JTextField();
		userNameValue.setBounds(150, 96, 320, 30);
		userNameValue.setBorder(BorderFactory.createMatteBorder(0,0,1,0, Color.BLACK));
		userNameValue.setOpaque(false);
		panel.add(userNameLabel);
		
		JButton registerApp = new JButton("REGISTER AS APPLICANT");
		registerApp.setBackground(new Color(0, 0, 0, 80));
		registerApp.setForeground(Color.white);
		
		JLabel errorLabelE = new JLabel("SOME FIELDS ARE EMPTY! PLEASE RETRY");
		errorLabelE.setBounds(0, 386, 500, 30);
		errorLabelE.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabelE.setForeground(Color.red);
		
		JLabel errorLabelP = new JLabel("PASSWORD AND CONFIRM PASSWORD DO NOT MATCH! PLEASE RETRY");
		errorLabelP.setBounds(0, 386, 500, 30);
		errorLabelP.setForeground(Color.red);
		errorLabelP.setHorizontalAlignment(SwingConstants.CENTER);
		
		registerApp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!passwordValue.getText().equals(confirmPasswordValue.getText())) {
					panel.add(errorLabelP);
					panel.remove(errorLabelE);
				}
				else if(userNameValue.getText().isEmpty() || eMailValue.getText().isEmpty() || phoneNumberValue.getText().isEmpty() || passwordValue.getText().isEmpty()) {
					panel.remove(errorLabelP);
					panel.add(errorLabelE);
				}
				else {
					panel.remove(errorLabelP);
					panel.remove(errorLabelE);
					String DB_URL = "jdbc:mysql://localhost/firstTry";
					String USER = "root";
					String PASS = "root";
					
					try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);) {
						int ApplicantID=-1;
						Statement stmt = conn.createStatement();
						
						String sqlRegister= "INSERT INTO applicantInfo (applicantName, applicantEMail, applicantMobile, applicantPassword) VALUES (?,?,?,?);";
			    		PreparedStatement st= conn.prepareStatement(sqlRegister);
			            st.setString(1, userNameValue.getText());
			            st.setString(2,eMailValue.getText());
			            st.setString(3,phoneNumberValue.getText());
			            st.setString(4,passwordValue.getText());
			            st.executeUpdate();

			            String QUERY = "SELECT applicantID FROM applicantInfo";
			            ResultSet rs = stmt.executeQuery(QUERY);
			            String sqlaa = "SELECT applicantID FROM applicantInfo" +" WHERE (applicantName = '"+userNameValue.getText()+"' and applicantMobile = '"+phoneNumberValue.getText()+"') and (applicantEMail = '"+eMailValue.getText()+"' and "+"applicantPassword = '"+passwordValue.getText()+"');";
			            System.out.println("sqlaa"+sqlaa);
			            rs = stmt.executeQuery(sqlaa);
			            while(rs.next())
			            	ApplicantID=rs.getInt("applicantID");
			            JOptionPane.showMessageDialog(contentPane, "Your ID is "+ApplicantID+"! Please save and use it to login further!");
			            viewApplicationDetails.userID="";
						viewApplicationDetails.userPassword="";
						viewApplicationDetails.main(null);
						dispose();
						
				conn.close();
			} catch (SQLException errorSQL) {
			}
				}
			}
		});
		registerApp.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.white));
//		btnNewButton.setBounds(50, 50, 100, 25);
		registerApp.setBounds(25, 436, 450, 30);
		panel.add(registerApp);
		
//		JSpinner m_numberSpinner;
//	    SpinnerNumberModel m_numberSpinnerModel;
//	    m_numberSpinnerModel = new SpinnerNumberModel(2023, 1910, 2023, 1);
//	    m_numberSpinner = new JSpinner(m_numberSpinnerModel);
//	    m_numberSpinner.setBounds(150, 276, 320, 30);
//	    m_numberSpinner.setOpaque(false);
//	    panel.add(m_numberSpinner);

//	    Calendar calendar = new GregorianCalendar(2000, Calendar.JANUARY, 1);
//	    spinner.setValue(calendar.getTime());
		
//		JLabel passwordLabel = new JLabel("PASSWORD");
//		passwordLabel.setBounds(25, 185, 100, 14);
//		JLabel lblNewLabel_3 = new JLabel("APPLICANT ID");
//		lblNewLabel_3.setBounds(25, 85, 149, 14);
		
//		JButton loginButton = new JButton("Login as Applicant");
//		loginButton.setBounds(102, 300, 146, 23);
//		loginButton.setBorder(BorderFactory.createMatteBorder(1,1,1,1, Color.BLACK));
//		loginButton.setBackground(new Color(0,0,0,0));
//		
//		JLabel registerNow = new JLabel("New to HIRE!ME ? Register as an applicant here!");
//		registerNow.addMouseListener(new MouseAdapter() {
//			@Override
//			public void mouseClicked(MouseEvent e) {
//				System.out.println(registerNow.getText());
//			}
//			public void mouseEntered(MouseEvent e) {
//				registerNow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//            	registerNow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//            }
//		});
//		registerNow.setBounds(0, 350, 350, 100);
//		registerNow.setHorizontalAlignment(SwingConstants.CENTER);
		
//		panel.remove(userIDValue);
//		panel.remove(lblNewLabel_3);
//		panel.remove(passwordLabel);
//		panel.remove(passwordValue);
//		panel.remove(loginButton);
//		userIDValue.setText(null);
//		passwordValue.setText(null);
//		panel.remove(registerNow);
		
		
//		lblNewLabel_3.setText("APPLICANT ID");
		panel.add(userNameValue);
//		panel.add(lblNewLabel_3);
//		panel.add(passwordLabel);
//		panel.add(passwordValue);
//		panel.add(loginButton);
//		loginButton.setLabel("Login as Applicant");
//		registerNow.setText("New to HIRE!ME ? Register as an applicant here!");
//		panel.add(registerNow);
		
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\shweta.rn\\Downloads\\Untitled design (16).gif"));
		lblNewLabel.setBounds(0, 0, 1280, 720);
		contentPane.add(lblNewLabel);
	}
}
